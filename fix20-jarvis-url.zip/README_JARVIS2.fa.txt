🎛️ اصلاح کامل مغز متنی جارویس — تغییر URL به OpenRouter رسمی
================================================================

▶ مرحله ۱: set_jarvis.php را داخل public_html آپلود کن (فقط همین یک فایل).

▶ مرحله ۲: ابتدا وضعیت فعلی را ببین (اختیاری ولی خوب است):
   https://test.amlak-e-man.ir/set_jarvis.php?key=jarvis-set-9f3c71ab60d54e8f&do=status
   (باید ببینی OPENROUTER_URL فعلی = https://ai.shayan-api.ir/... )

▶ مرحله ۳: اصلاح + تست خودکار (مهم! فقط همین آدرس را بزن):
   https://test.amlak-e-man.ir/set_jarvis.php?key=jarvis-set-9f3c71ab60d54e8f&do=set

   این کار انجام می‌دهد:
   ۱. OPENROUTER_MODEL → google/gemma-4-26b-a4b-it:free
   ۲. OPENROUTER_URL   → https://openrouter.ai/api/v1/chat/completions
   ۳. بک‌آپ از config.php قبلی (config.php.bak_jarvis)
   ۴. بلافاصله خودش به OpenRouter درخواست می‌زند و نتیجه را نشان می‌دهد

▶ نتیجه‌ای که می‌خواهیم ببینیم:
   HTTP : 200  +  «✅ مغز متنی جارویس کار می‌کند!»

▶ اگر باز هم 401/403 دیدی:
   یعنی کلید sk-or-v1-...  واقعاً باطل/نامعتبر شده است.
   → https://openrouter.ai/settings/keys → چک کن (لیست کلیدها + وضعیت)
   → اگر باطل بود، یک کلید جدید بساز و در config.php بگذار:
        define('OPENROUTER_API_KEY', 'sk-or-v1-کلید_جدید');

⚠️ بعد از موفقیت: set_jarvis.php را از هاست حذف کن.
