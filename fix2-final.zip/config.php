<?php
// 🔴 این فایل نباید در دسترس عموم باشد
// ⚠️ نسخهٔ امن‌شده — جایگزین پیکربندی قدیمی روی هاست (شناسه‌های دیتابیس همان‌هایی
//    است که الان روی هاست کار می‌کنند؛ چیزی از این بابت تغییر نمی‌کند).
//
//    تغییرات نسبت به نسخهٔ قبلی:
//     ۱) APP_SALT تصادفی ۶۴ کاراکتری → همهٔ نشست‌ها/توکن‌های قبلی باطل می‌شود
//        و همه باید دوباره وارد شوند (رفتار درست و عمدی است).
//     ۲) MASTER_PASSWORD_HASH هش از پیش محاسبه‌شده است؛ دیگر در هر درخواست
//        password_hash() اجرا نمی‌شود (۵۰ تا ۱۰۰ms صرفه‌جویی در هر درخواست).
//     ۳) ALLOWED_ORIGIN فقط دامنهٔ تست است، نه '*'.
//     ۴) تنظیمات STT و OpenRouter به‌صورت ثابت در همین فایل.
// ============================================================================

define('DB_HOST', 'localhost');
define('DB_NAME', 'owihpfoa_Amlak-E-Man_Database');
define('DB_USER', 'owihpfoa_Amlak-E-Man_Database');
define('DB_PASS', 'Mx3eu4rR7ydyVyynfnGM');
// ⚠️⚠️ این رمز دیتابیس در Test.zip (که در گیت است) منتشر شده — حتماً عوضش کن:
//    DirectAdmin → Account Manager → MySQL Management → روی دیتابیس کلیک →
//    کنار کاربر → Change Password → یک رمز جدید بگذار و همین DB_PASS را
//    با همان مقدار عوض کن. تا آن زمان سایت با رمز فعلی کار می‌کند.

// ── رمز عبور مدیریت کل (مالک سیستم) ─────────────────────────────────────────
// برای تغییر، هش جدید را با این دستور بساز (روی هاست، از SSH):
//    php -r "echo password_hash('رمز_جدید_تو', PASSWORD_DEFAULT), PHP_EOL;"
// و همین‌جا جایگزین کن.
define('MASTER_PASSWORD_HASH', '$2y$10$GZOcU/yuntC5LJezUAdBdeOW.3dOSCEk.kCuylqmtonPbsItwYu4m');

// ── کلید امضای توکن‌ها ──────────────────────────────────────────────────────
define('APP_SALT', 'f7c3c9d2ae006bbde1d5dfabe6304f73ac0ffb771182ae0dfdae0fbf62dbc3c2');

// ── دامنهٔ مجاز برای CORS ───────────────────────────────────────────────────
define('ALLOWED_ORIGIN', 'https://test.amlak-e-man.ir');

// ============================================================================
// 🎙️ تبدیل گفتار به متن (STT) — جارویس صوتی
//    STT_PROVIDER: 'hf' (Hugging Face) | 'groq' (پیشنهادی برای فارسی) | 'openai'
//    قبل از پر کردن کلید، php tools/stt_probe.php را اجرا کن تا مطمئن شوی
//    ارائه‌دهنده روی هاست تو واقعاً جواب می‌دهد.
// ============================================================================
define('STT_PROVIDER', 'hf');
define('STT_HF_TOKEN', '');
define('STT_MODEL', 'openai/whisper-large-v3');
define('STT_GROQ_KEY', '');
define('STT_MODEL_GROQ', 'whisper-large-v3-turbo');
define('STT_OPENAI_KEY', '');
define('STT_MODEL_OPENAI', 'whisper-1');
define('STT_LANGUAGE', 'fa');
define('STT_MAX_BYTES', 8 * 1024 * 1024);
define('STT_TIMEOUT', 45);
define('STT_CONNECT_TIMEOUT', 10);

// ============================================================================
// 🧠 مغز جارویس (OpenRouter)
// ============================================================================
define('OPENROUTER_API_KEY', '');
define('OPENROUTER_URL', 'https://ai.shayan-api.ir/api/v1/chat/completions');
define('OPENROUTER_MODEL', 'laguna-xs-2.1:free');
?>
