<?php echo "PROBE-MAIN-PHP ", PHP_VERSION, "\n";
