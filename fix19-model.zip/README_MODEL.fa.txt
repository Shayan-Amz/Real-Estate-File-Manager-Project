🎛️ تغییر مدل جارویس (مغز متنی) — google/gemma-4-26b-a4b-it:free
====================================================================

▶ مرحله ۱: فایل set_model.php را داخل public_html آپلود کن (فقط همین یک فایل).

▶ مرحله ۲: این آدرس را در مرورگر باز کن (مدل به‌صورت خودکار عوض می‌شود):
   https://test.amlak-e-man.ir/set_model.php?key=setmodel-9f3c71ab60d54e8f&model=google/gemma-4-26b-a4b-it:free

   باید ببینی: «✅ مدل جارویس عوض شد — مدل قدیمی: laguna-xs-2.1:free / مدل جدید: google/gemma-4-26b-a4b-it:free»

▶ مرحله ۳: دوباره تست بزن و خروجی کامل را بفرست:
   https://test.amlak-e-man.ir/stt_test.php?key=stt-test-9f3c71ab60d54e8f
   در بخش «مغز متنی جارویس (OpenRouter)» باید HTTP 200 و پاسخ معتبر ببینیم.

▶ اگر باز هم 403 دیدی:
   یعنی مشکل از URL سفارشی است (https://ai.shayan-api.ir/...) نه مدل.
   در config.php این خط را عوض کن:
       define('OPENROUTER_URL', 'https://openrouter.ai/api/v1/chat/completions');
   و دوباره تست بزن.

⚠️ بعد از موفقیت، set_model.php را از هاست حذف کن.
