<?php echo "PROBE-TEST-PHP ", PHP_VERSION, "\n";
