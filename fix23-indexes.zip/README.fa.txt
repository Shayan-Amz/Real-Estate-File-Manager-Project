════════════════════════════════════════════════════════════
fix23 — ایندکس روی ستون‌های داغ   (مرحلهٔ ۲ از ۴)
════════════════════════════════════════════════════════════

نصب:
  ۱) api.php              → public_html
  ۲) tools/health_check.php → public_html/tools
  ۳) یک بار سایت را باز کن تا مهاجرت اجرا شود
  ۴) health_check را باز کن و بخش ۵ را ببین


مشکل چه بود؟
────────────
grep روی ADD INDEX / ADD KEY / CREATE INDEX در کل پروژه هیچ نتیجه نداد.
یعنی هیچ‌کدام از جداول داغ ایندکس نداشتند و هر کوئری full table scan بود.

داغ‌ترین کوئریِ برنامه این است (api.php خط ۳۳۲):

    SELECT status FROM members WHERE name = ? AND agencyId = ?

و روی «هر» درخواست احراز هویت‌شده اجرا می‌شود — چون اعتبار توکن
مشاور همین‌جا چک می‌شود.


چه ایندکس‌هایی ساخته می‌شود؟
──────────────────────────
    members     idx_agency_name   (agencyId, name)
    properties  idx_agencyId      (agencyId)
    properties  idx_status_guest  (status, showToGuest)
    demands     idx_agencyId      (agencyId)

چرا members ترکیبی است: یک ایندکس (agencyId, name) هم کوئری داغ بالا را
پوشش می‌دهد و هم «members WHERE agencyId = ?» را. پس دو ایندکس لازم نیست.

چرا agencies ایندکس نگرفت: کوئری‌هایش «WHERE id = ?» هستند و id تقریباً
مطمئناً کلید اصلی است.


چه چیزی باید بدانید
───────────────────
• مهاجرت فقط «یک بار» اجرا می‌شود، چون SCHEMA_VERSION از ۵ به ۶ رفت.
  بعد از آن در ریکوئست‌های بعدی رد می‌شود.
• ALTER TABLE جدول را لحظه‌ای قفل می‌کند. با حجم فعلی دادهٔ شما قابل
  توجه نیست، ولی اگر جدول properties خیلی بزرگ بود چند ثانیه صبر کن.
• هر ALTER در try/catch جداست. اگر یکی شکست خورد (مثلاً ستونش وجود
  نداشت)، بقیه ساخته می‌شوند و سایت از کار نمی‌افتد. دلیلش در error_log
  ثبت می‌شود.


چطور مطمئن شوم ساخته شد؟
────────────────────────
health_check.php بخش ۵ حالا ایندکس‌ها را فهرست می‌کند:

    https://test.amlak-e-man.ir/tools/health_check.php?key=hk_9f3c71ab60d54e8fa2c17be4d5096e38

باید این چهار خط سبز باشند:
    ✅ members.idx_agency_name (agencyId,name)
    ✅ properties.idx_agencyId (agencyId)
    ✅ properties.idx_status_guest (status,showToGuest)
    ✅ demands.idx_agencyId (agencyId)


هنوز مانده (مرحلهٔ بعد نیست — فقط برای اطلاع)
────────────────────────────────────────────
کوئری املاک این شکل است:
    WHERE agencyId = ? OR (status = 'موجود' AND showToGuest = 1)
آن OR باعث می‌شود MySQL حتی با ایندکس هم اغلب اسکن کند. ایندکس
idx_status_guest کمک می‌کند ولی راه‌حل قطعی، شکستن کوئری به UNION است.
اگر خواستی بعداً جداگانه انجامش می‌دهم.


اعتبارسنجی انجام‌شده
────────────────────
- api.php با php-parser پارس شد: ۴۳ گره، بدون خطا
- tools/health_check.php پارس شد: ۸۶ گره، بدون خطا
- جای بلوک مهاجرت با شمارش آکولاد بررسی شد: عمق ۴، درست قبل از
  «پایان if properties exists» — یعنی داخل بلوک درست است
- هر ۴ دستور ALTER با node-sql-parser به‌عنوان MySQL پارس شدند: ۴/۴ معتبر
- SCHEMA_VERSION از ۵ به ۶ رفت (وگرنه مهاجرت اجرا نمی‌شد)

⚠️ هیچ PHP ای اجرا نشد — ساخته‌شدن واقعی ایندکس‌ها باید روی هاست
   از طریق health_check بخش ۵ تأیید شود.
