<?php
http_response_code(200);
header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store, max-age=0');
echo 'OK-CANARY-PHP-20260906-1900 PHP=' . PHP_VERSION . ' SAPI=' . PHP_SAPI . "\n";
